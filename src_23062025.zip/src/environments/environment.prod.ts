export const environment = {
  production: true,
  apiBaseUrl : 'https://c2k2dev.com/ncpl/'
};
