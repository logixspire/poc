package com.logixspire.remedi.plugins;

import android.content.Intent;
import android.content.ComponentName;
import android.util.Log;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.JSObject;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "NovaIcareLauncherPlugin")
public class NovaIcareLauncherPlugin extends Plugin {
    public NovaIcareLauncherPlugin() {
        Log.d("NovaIcare", "✅ NovaIcareLauncherPlugin loaded");
    }

    @PluginMethod
    public void launchStethoWithResult(PluginCall call) {
        Log.d("NovaIcare", "🚀 Plugin method invoked");

        Intent intent = new Intent();
        intent.setComponent(new ComponentName("com.neurosynaptic.nova_icare", "com.neurosynaptic.usb.StethoSensor"));
        getContext().startActivity(intent);

        JSObject result = new JSObject();
        result.put("status", "launched");
        call.resolve(result);
    }
}