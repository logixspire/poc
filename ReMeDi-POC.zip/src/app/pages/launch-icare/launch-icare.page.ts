import { Component, OnInit } from '@angular/core';
import { NovaIcareLauncher } from 'src/app/plugins/nova-icare-launcher';
import { NovaIcareService } from 'src/app/services/nova-icare.service';

@Component({
  selector: 'app-launch-icare',
  templateUrl: './launch-icare.page.html',
  styleUrls: ['./launch-icare.page.scss'],
  standalone:false
})
export class LaunchIcarePage implements OnInit {

  ngOnInit(): void {
    // this.launchStethoscope()
  }
  
 async launchStethoscope() {
    // try {
    //   const result = await NovaIcareLauncher.launchStethoWithResult({
    //     // class_name: 'com.logixspire.remedi.MainActivity',
    //     // package_name: 'com.logixspire.remedi',
    //     // class_name: 'com.neurosynaptic.nova_icare',
    //     // package_name: 'com.neurosynaptic.usb.StethoSenso',
    //     class_name: 'com.neurosynaptic.ble.sensors.CE_Certification_Luncher_Activity',
    //     package_name: 'com.neurosynaptic.nova_icare',
    //     language: 'en',
    //     patient_id: '12345',
    //     real_id: '' // optional
    //   });

    //   console.log('Stethoscope Reading:', result);
    //   // You can save it to DB, display in chart, etc.
    // } catch (error) {
    //   console.error('Error:', error);
    // }

     NovaIcareLauncher.launchStethoWithResult({
      class_name: 'com.neurosynaptic.ble.sensors.CE_Certification_Luncher_Activity',
      package_name: 'com.neurosynaptic.nova_icare',
      language: 'en',
      patient_id: '12345',
      real_id: ''
    }).then(res => {
      console.log('Launch success:', res);
    }).catch(err => {
      console.error('Launch failed:', err);
    });
  }
}
