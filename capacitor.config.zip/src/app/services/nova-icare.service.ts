import { registerPlugin } from '@capacitor/core';

// import type { NovaIcareLauncherPlugin } from '../../../plugins/nova-icare-launcher';

// const NovaIcareLauncher = registerPlugin<NovaIcareLauncherPlugin>('NovaIcareLauncher');

export class NovaIcareService {
  // async launchStethoscope() {
  //   try {
  //     const result = await NovaIcareLauncher.launchStethoscope({
  //       pid: '12345',
  //       className: 'StethoSensor',
  //       packageName: 'com.logixspire.remedi',
  //       language: 'en'
  //     });
  //     console.log('Received result from nova-icare:', result.result);
  //   } catch (error) {
  //     console.error('Error launching stethoscope:', error);
  //   }
  // }
}
