package com.logixspire.remedi.plugins;

import android.content.Intent;
import android.content.ComponentName;
import android.util.Log;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.JSObject;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "NovaIcareLauncherPlugin")
public class NovaIcareLauncherPlugin extends Plugin {

  // public NovaIcareLauncherPlugin() {
  //     Log.d("NovaIcare", "✅ NovaIcareLauncherPlugin loaded");
  // }

  @PluginMethod
  public void launchStethoWithResult(PluginCall call) {
    Log.d("NovaIcare", "🚀 Plugin method launchStethoWithResult invoked");

    try {
      Intent intent = new Intent();
      intent.putExtra("USE_SENSOR", true);
      intent.putExtra("class_name", call.getString("class_name"));
      intent.putExtra("useflag", "0");
      intent.putExtra("package_name", call.getString("package_name"));
      intent.putExtra("language", call.getString("language"));

      String realId = call.getString("real_id");
      if (realId == null || realId.isEmpty()) {
        intent.putExtra("pid", call.getString("patient_id"));
      } else {
        intent.putExtra("pid", realId);
      }

      intent.setComponent(new ComponentName(
        "com.neurosynaptic.nova_icare",
        "com.neurosynaptic.usb.StethoSensor"
      ));

      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      getContext().startActivity(intent);

      JSObject result = new JSObject();
      result.put("status", "launched");
      call.resolve(result);

    } catch (Exception e) {
      call.reject("Failed to launch intent", e);
    }
  }
}
