
  cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
      {
          "id": "com.napolitano.cordova.plugin.intent.IntentPlugin",
          "file": "plugins/com.napolitano.cordova.plugin.intent/www/android/IntentPlugin.js",
          "pluginId": "com.napolitano.cordova.plugin.intent",
        "clobbers": [
          "IntentPlugin"
        ]
        },
      {
          "id": "com-darryncampbell-cordova-plugin-intent.IntentShim",
          "file": "plugins/com-darryncampbell-cordova-plugin-intent/www/IntentShim.js",
          "pluginId": "com-darryncampbell-cordova-plugin-intent",
        "clobbers": [
          "intentShim"
        ]
        }
    ];
    module.exports.metadata =
    // TOP OF METADATA
    {
      "com-darryncampbell-cordova-plugin-intent": "2.2.0",
      "com.napolitano.cordova.plugin.intent": "0.1.2"
    };
    // BOTTOM OF METADATA
    });
    